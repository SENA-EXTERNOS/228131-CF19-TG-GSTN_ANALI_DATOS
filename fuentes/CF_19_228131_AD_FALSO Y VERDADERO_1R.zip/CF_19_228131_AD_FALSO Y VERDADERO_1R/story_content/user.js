function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5VFedif3uz3":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

