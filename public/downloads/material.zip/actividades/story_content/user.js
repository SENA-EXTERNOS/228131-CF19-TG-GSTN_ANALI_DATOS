function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5iFsneKvGep":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

